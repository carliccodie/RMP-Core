package com.carlic.RmpCore.chemistry.ore;

import com.carlic.RmpCore.chemistry.element.ElementDatabase;
import com.carlic.RmpCore.chemistry.mineral.MineralCompositionCalculator;
import com.carlic.RmpCore.chemistry.mineral.MineralData;
import com.carlic.RmpCore.chemistry.mineral.MineralDatabase;
import com.carlic.RmpCore.chemistry.ore.OreDatabase;

import java.util.LinkedHashMap;
import java.util.Map;

public final class OreGradeCalculator {

    private final MineralDatabase mineralDatabase;
    private final ElementDatabase elementDatabase;
    private final MineralCompositionCalculator mineralCompositionCalculator;
    private final OreDatabase oreDatabase;

    public OreGradeCalculator(
            MineralDatabase mineralDatabase,
            ElementDatabase elementDatabase,
            MineralCompositionCalculator mineralCompositionCalculator,
            OreDatabase oreDatabase
    ) {
        if (mineralDatabase == null
                || elementDatabase == null
                || oreDatabase == null
                || mineralCompositionCalculator == null) {
            throw new IllegalArgumentException(
                    "Ore grade calculator dependencies cannot be null."
            );
        }

        this.oreDatabase = oreDatabase;
        this.mineralDatabase = mineralDatabase;
        this.elementDatabase = elementDatabase;
        this.mineralCompositionCalculator = mineralCompositionCalculator;
    }

    /**
     * Calculates elemental mass grades from the mineral composition of an ore.
     *
     * Mineral percentages must represent mass percentages and total 100%.
     *
     * @param oreId ore database ID
     * @return map of element symbols to mass percentages in the ore
     */
    public Map<String, Double> calculateAllElementGrades(String oreId) {
        if (oreId == null || oreId.isBlank()) {
            throw new IllegalArgumentException(
                    "Ore ID cannot be null or blank."
            );
        }

        OreData ore = findOre(oreId);

        Map<String, Double> grades = new LinkedHashMap<>();

        for (Map.Entry<String, Double> entry
                : ore.mineralComposition().entrySet()) {

            String mineralId = entry.getKey();
            double mineralPercentage = entry.getValue();

            MineralData mineral = mineralDatabase.getById(mineralId);

            if (mineral == null) {
                throw new IllegalArgumentException(
                        "Unknown mineral ID in ore "
                                + oreId + ": " + mineralId
                );
            }

            Map<String, Double> mineralElementPercentages =
                    mineralCompositionCalculator
                            .calculateAllElementMassPercentages(mineralId);

            for (Map.Entry<String, Double> elementEntry
                    : mineralElementPercentages.entrySet()) {

                String elementSymbol = elementEntry.getKey();

                if (elementDatabase.getBySymbol(elementSymbol) == null) {
                    throw new IllegalArgumentException(
                            "Unknown element symbol: " + elementSymbol
                    );
                }

                double contribution =
                        mineralPercentage * elementEntry.getValue() / 100.0;

                grades.merge(
                        elementSymbol,
                        contribution,
                        Double::sum
                );
            }
        }

        return Map.copyOf(grades);
    }

    /**
     * Calculates the mass percentage of one element in an ore.
     *
     * @param oreId ore database ID
     * @param elementSymbol element symbol
     * @return elemental mass percentage
     */
    public double calculateElementGrade(
            String oreId,
            String elementSymbol
    ) {
        if (elementSymbol == null || elementSymbol.isBlank()) {
            throw new IllegalArgumentException(
                    "Element symbol cannot be null or blank."
            );
        }

        if (elementDatabase.getBySymbol(elementSymbol) == null) {
            throw new IllegalArgumentException(
                    "Unknown element symbol: " + elementSymbol
            );
        }

        return calculateAllElementGrades(oreId)
                .getOrDefault(elementSymbol, 0.0);
    }

    private OreData findOre(String oreId) {
        OreData ore = oreDatabase.getById(oreId);

        if (ore == null) {
            throw new IllegalArgumentException(
                    "Unknown ore ID: " + oreId
            );
        }

        return ore;
    }
}